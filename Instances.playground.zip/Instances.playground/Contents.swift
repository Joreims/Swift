import Foundation
let literalString = "Howdy"
let literalBool = false
let literalInt = 84

let rightNow = Date()

let emptyString = String()
let falseBool = Bool()
let zero = Int()

let oneHourLater = Date(timeIntervalSinceNow: 3600)

let introduction = "It was a dark abd stormy night"
let alternateIntroduction = "Once upon a time"

introduction.hasPrefix("It was")
introduction.hasPrefix("It wasn't")
alternateIntroduction.hasPrefix("It was")
alternateIntroduction.hasPrefix("It wasn't")


let number = 42
//number.hasPrefix("It was")


var isEmpty: Bool { get }
let something = "It was the best of times"
something.isEmpty

let nothing = " "
nothing.isEmpty

var magic = "Now you see it"
magic.removeAll()
magic

let example = "It was the best of times"

example
